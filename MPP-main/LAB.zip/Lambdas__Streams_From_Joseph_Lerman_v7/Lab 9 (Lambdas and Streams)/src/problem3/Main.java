package problem3;

import java.util.Arrays;
import java.util.List;

public class Main {
	
	public static int countWords(List<String> words, char c, char d, int len) {
		long output = words.stream()
				.filter(s -> s.length() == len && s.contains(Character.toString(c)) && !s.contains(Character.toString(d)))
				.count();
		return (int)output;
	}

	public static void main(String[] args) {
		
		String[] arr = {"cook","dog","car","coat","code", "cone", "boy"};
		List<String> list = Arrays.asList(arr);
		
		System.out.println(countWords(list, 'c', 'd', 4));
		
	}

}
