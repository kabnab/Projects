package problem5;

import java.util.ArrayList;
import java.util.List;

public class Department {
	
	private String name;
	private String location;
	private List<Position> positions;
	
	Department(String name, String location){
		this.name = name;
		this.location = location;
		this.positions = new ArrayList<Position>();
	}
	
	Department(){
		
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public List<Position> getPositions() {
		return positions;
	}

	public void setPositions(List<Position> positions) {
		this.positions = positions;
	}
	
	public void addPosition(Position p) {
		positions.add(p);
	}
	
	public void print() {
		System.out.print("---------------------------\n" 
						+ name + " Department" + " (" + location +")"+ "\n" 
						+ "---------------------------\n");
		positions.forEach(Position::print);
	}
	
	public double getSalary() {
		return positions.stream().mapToDouble(Position::getSalary).sum();
	}

}
