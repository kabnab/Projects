package problem5;

import java.time.LocalDate;

public class Application {

	public static void main(String[] args) {
		
		Company theCompany = new Company("KIA MOTORS");
		
		Department salesDep = new Department("Sales", "Verginia");
		Department serviceDep = new Department("Maintenance", "Iowa");
		
		theCompany.addDepartment(salesDep);
		theCompany.addDepartment(serviceDep);
		
		Employee emp1 = new Employee(100, "John", 'K', "Thomas", LocalDate.of(1985, 12, 5), "56-8909-345", 65000);
		Employee emp2 = new Employee(200, "Eric", 'W', "Allen", LocalDate.of(1995, 1, 15), "56-8909-345", 45000);
		Employee emp3 = new Employee(300, "Carry", 'B', "Daniel", LocalDate.of(1988, 7, 25), "56-8909-345", 85000);
		Employee emp4 = new Employee(400, "Elias", 'N', "Cruz", LocalDate.of(1985, 10, 9), "56-8909-345", 35000);
		
		Position salesMan = new Position("Sales Agent", "Sales Person", emp1);
		Position cashier = new Position("Cash Officer", "Sales Cash Handler", emp2);
		Position accountant = new Position("Accounts Officer", "Head of Accounting", null);
		Position technician = new Position("Mechanic", "Vehicle Maintenance", emp3);
		Position purchaser = new Position("Supply Officer", "Parts Supply", null);
		Position greeter = new Position("Front Officer", "Client Service", emp4);

		salesDep.addPosition(salesMan);
		salesDep.addPosition(cashier);
		salesDep.addPosition(accountant);
		
		serviceDep.addPosition(technician);
		serviceDep.addPosition(purchaser);
		serviceDep.addPosition(greeter);
		
		
		salesMan.setEmployee(emp1);
		cashier.setEmployee(emp2);
		technician.setEmployee(emp3);
		greeter.setEmployee(emp4);
		
		theCompany.print();
		System.out.printf("\nTOTAL Salary of %s is $ %,.2f", theCompany.getName(),theCompany.getSalary());
	}
}
