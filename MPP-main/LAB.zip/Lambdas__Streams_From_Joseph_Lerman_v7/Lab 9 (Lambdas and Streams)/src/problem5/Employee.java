package problem5;

import java.time.LocalDate;

public class Employee {
	
	private int employeeId;
	private String firstName;
	private char middleInitial;
	private String lastName;
	private LocalDate birthDate;
	private String ssn;
	private double salary;
	private Position ePosition;
	
	public Employee(int employeeId, String firstName, char middleInitial, String lastName, LocalDate birthDate,
					String ssn, double salary) {
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.middleInitial = middleInitial;
		this.lastName = lastName;
		this.birthDate = birthDate;
		this.ssn = ssn;
		this.salary = salary;
		ePosition = new Position();
	}
	
	Employee(){
		
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public char getMiddleInitial() {
		return middleInitial;
	}

	public void setMiddleInitial(char middleInitial) {
		this.middleInitial = middleInitial;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public LocalDate getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(LocalDate birthDate) {
		this.birthDate = birthDate;
	}
	
	public String getSsn() {
		return ssn;
	}

	public void setSsn(String ssn) {
		this.ssn = ssn;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	public Position getPosition() {
		return ePosition;
	}

	public void setPosition(Position ePosition) {
		this.ePosition = ePosition;
	}
	
	public void print() {
		String f = "  Employee ID: %d%n  Name: %s %c. %s";
		System.out.printf(f, employeeId, firstName, middleInitial, lastName);
		System.out.println("\n  Birthday: " + birthDate.toString());
		System.out.println("  SSN: " + ssn);
		System.out.printf("  Salary: $ %,.2f%n", salary);
	}

}
