package problem6;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.Map;
import java.util.Optional;
import java.util.TreeMap;


public class ProcessingEmployees {
	
	public static void main(String[] args) {
		
		// initialize array of Employees
	    Employee[] employees = {
	    		new Employee("Jason", "Red", 5000, "IT"),
	    		new Employee("Ashley", "Green", 7600, "IT"),
	    		new Employee("Matthew", "Indigo", 3587.5, "Sales"),
	    		new Employee("James", "Indigo", 4700.77, "Marketing"),
	    		new Employee("Luke", "Indigo", 6200, "IT"),
	    		new Employee("Jason", "Blue", 3200, "Sales"),
	    		new Employee("Wendy", "Brown", 4236.4, "Marketing")};
	    
	    // get List view of the Employees
	    List<Employee> list = Arrays.asList(employees);
	    	    
	    //Lab9 - Problem 6(a) Print out each department and the average salary for the department.
	    System.out.println("6.a..............................................");
	    System.out.printf("%nAverage Salary by Department:%n");
	    Map<String, Double> avSalaryByDep = list.stream().collect(Collectors.groupingBy(Employee::getDepartment, 
	    															TreeMap::new, 
	    															Collectors.averagingDouble(Employee::getSalary)));
	    avSalaryByDep.forEach((dep, av) -> System.out.printf(" %s Department has Average Salary of %,.2f%n", dep, av));
	    
	    //Lab9 - Problem 6(b) Print out each department and the maximum salary for the department.
	    System.out.println("\n6.b..............................................");
	    System.out.printf("%nMaximum Salary by Department:%n");
	    Map<String, Optional<Employee>> maxSalaryByDep = list.stream().collect(Collectors.groupingBy(Employee::getDepartment,
	    																			TreeMap::new,
	    																			Collectors.maxBy(Comparator.comparing(Employee::getSalary))));
	    maxSalaryByDep.forEach((dep, emp) -> System.out.printf(" %s Department has Maximum Salary of %,.2f%n", dep, emp.get().getSalary()));
	    
	    //Lab9 - Problem 6(c) Print out each department and all of the employees who work at that department.
	    System.out.println("\n6.c..............................................");
	    System.out.printf("%nDepartments and their Employees:%n");
	    Map<String, List<Employee>> employeesInDepartments = list.stream()
	    														 .collect(Collectors.groupingBy(Employee::getDepartment));
	    employeesInDepartments.forEach((dep, emps) -> {
	    							System.out.printf("%n Employees in %s%n", dep);
	    							emps.forEach(a -> System.out.println("  " + a.getName()));
	    });
	    
	}

}
