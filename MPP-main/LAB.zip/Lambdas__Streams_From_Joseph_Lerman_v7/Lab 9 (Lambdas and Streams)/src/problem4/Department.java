package problem4;

import java.util.ArrayList;
import java.util.List;

public class Department {
	
	private String depName;
	private List<Person> persons = new ArrayList<>();
	
	public Department(String depName, List<Person> persons) {
		this.depName = depName;
		this.persons = persons;
	}
	
	public Department(String depName) {
		this.depName = depName;
	}
	
	public String getDepName() {
		return depName;
	}

	public void setDepName(String depName) {
		this.depName = depName;
	}

	public List<Person> getPersons() {
		return persons;
	}

	public void setPersons(List<Person> persons) {
		this.persons = persons;
	}
	
	public void addPerson(Person p) {
		persons.add(p);
	}
	
	public double getTotalSalary() {
		return persons.stream().mapToDouble(Person::getSalary).sum();
	}
	
	public void showAllMembers() {
		System.out.println("List of " + getDepName() + " Deparment Members");
		persons.stream().forEach(p -> System.out.printf("%nMember Name: %-15sPhone Number: %-12sAge: %-5dGroup: %s", 
				p.getName(), p.getPhone(), p.getAge(), p.getClass().getSimpleName()));
	}
	
	public void unitsPerFaculty() {
		System.out.print("\n\nNumber of Units per Faculty");
		persons.stream().filter(p -> p instanceof Faculty).forEach(p -> System.out.printf("%nFaculty Name: %-15sCourse Units: %d", 
				p.getName(), p.getTotalUnits()));
	}
	
	public void returnStudentsOf(String facultyName) {
		System.out.println("\n\nStudents of " + facultyName + " are:");
		List<Course> courses = persons.stream().filter(p -> p instanceof Faculty)
								.filter(p -> p.getName() == facultyName)
								.map(f -> (Faculty)f).findFirst().get().getCourses();
		List<Student> students = new ArrayList<>();
		persons.stream().filter(p -> p instanceof Student).map(p -> (Student)p)
						.forEach(s -> {
							s.getCourses().forEach(c -> {if(courses.contains(c))students.add(s);});
						});
		students.stream().distinct().map(Student::getName).forEach(System.out::println);
	}

}
