

public abstract class AItem implements IItem{
	
	private String title;
	
	public AItem(String title) {
		this.title = title;
	}
	
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public abstract boolean checkAvailability();

}
