

public class Magazine extends AItem{
	
	private String issueNumber;
	
	public Magazine(String title, String issueNumber) {
		super(title);
		this.issueNumber = issueNumber;
	}

	public String getIssueNumber() {
		return issueNumber;
	}

	public void setIssueNumber(String issueNumber) {
		this.issueNumber = issueNumber;
	}
	
	public boolean checkAvailability() {
		return false;
	}
}
