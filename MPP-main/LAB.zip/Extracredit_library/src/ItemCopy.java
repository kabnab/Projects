

public class ItemCopy implements IItemCopy{
	
	private String copyId;
	private boolean available;
	private Loan loan;
	private IItem Item;
	
	public ItemCopy(String copyId, boolean available) {
		this.copyId = copyId;
		this.available = available;
	}

	public String getCopyId() {
		return copyId;
	}

	public boolean isAvailable() {
		return available;
	}

	public void setCopyId(String copyId) {
		this.copyId = copyId;
	}

	public void setAvailable(boolean available) {
		this.available = available;
	}

	public Loan getLoan() {
		return loan;
	}

	public void setLoan(Loan loan) {
		this.loan = loan;
	}

	public IItem getItem() {
		return Item;
	}

	public void setItem(IItem item) {
		Item = item;
	}

}
