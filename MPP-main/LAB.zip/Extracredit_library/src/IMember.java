

public interface IMember {

}
