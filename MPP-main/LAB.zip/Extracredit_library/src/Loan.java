

import java.time.LocalDate;

public class Loan {
	
	private LocalDate check_out_date;
	private LocalDate return_date;
	private IItemCopy itemCopy;
	
	public Loan(LocalDate check_out_date, LocalDate return_date, IItemCopy itemCopy) {
		this.check_out_date = check_out_date;
		this.return_date = return_date;
		this.itemCopy = itemCopy;
	}

	public LocalDate getCheck_out_date() {
		return check_out_date;
	}

	public LocalDate getReturn_date() {
		return return_date;
	}

	public IItemCopy getItemCopy() {
		return itemCopy;
	}

	public void setCheck_out_date(LocalDate check_out_date) {
		this.check_out_date = check_out_date;
	}

	public void setReturn_date(LocalDate return_date) {
		this.return_date = return_date;
	}

	public void setItemCopy(IItemCopy itemCopy) {
		this.itemCopy = itemCopy;
	}

}
