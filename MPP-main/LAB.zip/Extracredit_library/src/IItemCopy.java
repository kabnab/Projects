

public interface IItemCopy {

}
