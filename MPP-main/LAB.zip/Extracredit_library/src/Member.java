

import java.util.ArrayList;
import java.util.List;

public class Member implements IMember{
	
	private String id;
	private String name;
	private String address;
	private String phone;
	private List<Loan> loans = new ArrayList<>();
	private List<Reservation> reservations = new ArrayList<>();
	private Library library;
	
	public Member(String id, String name, String address, String phone) {
		this.id = id;
		this.name = name;
		this.address = address;
		this.phone = phone;
	}

	public String getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getAddress() {
		return address;
	}

	public String getPhone() {
		return phone;
	}
	
	public List<Loan> getLoans() {
		return loans;
	}
	
	public void setId(String id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public List<Reservation> getReservations() {
		return reservations;
	}

	public void setReservations(List<Reservation> reservations) {
		this.reservations = reservations;
	}
	
	public void addLoans(Loan l) {
		loans.add(l);
	}

	public void addReservations(Reservation r) {
		reservations.add(r);
	}
	
	public void reserve(Reservation r) {
		if(r.isAvailable()) this.addReservations(r);
	}
	
	public void borrow(Loan l) {
		addLoans(l);
		library.getItemCopies().remove(l.getItemCopy());
	}
	
	public void returnLoan(Loan l) {
		for(Loan i : loans) {
			if(i.equals(l)) loans.remove(l);
		}
		library.getItemCopies().add(l.getItemCopy());
	}
	
}
