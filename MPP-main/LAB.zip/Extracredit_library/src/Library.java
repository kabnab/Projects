

import java.util.ArrayList;
import java.util.List;

public class Library {
	
	private List<IMember> members = new ArrayList<>();
	private List<IItemCopy> itemCopies = new ArrayList<>();
	
	public Library(List<IMember> members, List<IItemCopy> itemCopies) {
		this.members = members;
		this.itemCopies = itemCopies;
	}

	public List<IMember> getMembers() {
		return members;
	}

	public List<IItemCopy> getItemCopies() {
		return itemCopies;
	}

	public void setMembers(List<IMember> members) {
		this.members = members;
	}

	public void setItemCopies(List<IItemCopy> itemCopies) {
		this.itemCopies = itemCopies;
	}
	
	public void addMembers(IMember im) {
		members.add(im);
	}
	
	public void addItemCopy(IItemCopy ic) {
		itemCopies.add(ic);
	}

}
