

import java.util.ArrayList;
import java.util.List;

public class Book extends AItem{
	
	private String isbn;
	private List<String> authors = new ArrayList<>();
	
	public Book(String title, String isbn) {
		super(title);
		this.isbn = isbn;
	}

	public String getIsbn() {
		return isbn;
	}

	public List<String> getAuthors() {
		return authors;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public void setAuthors(List<String> authors) {
		this.authors = authors;
	}
	
	public void addAuthors(String s) {
		authors.add(s);
	}
	
	public boolean checkAvailability() {
		return false;
	}

}
