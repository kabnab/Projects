

public interface IItem {
	
	public boolean checkAvailability();

}
