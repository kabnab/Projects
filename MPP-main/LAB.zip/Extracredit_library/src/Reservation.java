
import java.time.LocalDate;

public class Reservation {
	
	private LocalDate reservatioDate;
	private IItem item;
	
	public Reservation(LocalDate reservatioDate, IItem item) {
		this.reservatioDate = reservatioDate;
		this.item = item;
	}

	public LocalDate getReservatioDate() {
		return reservatioDate;
	}

	public IItem getItem() {
		return item;
	}

	public void setReservatioDate(LocalDate reservatioDate) {
		this.reservatioDate = reservatioDate;
	}

	public void setItem(IItem item) {
		this.item = item;
	}
	
	public boolean isAvailable() {
		return item.checkAvailability();
	}
	

}
