

import java.time.LocalDate;

public class StaffStudent extends Student{
	
	private Staff studentStaff = new Staff(null,null,0,0);
	private LocalDate startDate;

	public StaffStudent(String name, String phone, int age, double gpa, int yy, int mm, int dd) {
		super(name, phone, age, gpa);
		this.startDate = LocalDate.of(yy, mm, dd);
	}
	
	public StaffStudent(String name, String phone, int age, double gpa, double salary) {
		super(name, phone, age, gpa);
		studentStaff.setSalary(salary);
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public Staff getStudentStaff() {
		return studentStaff;
	}

	public void setStudentStaff(Staff studentStaff) {
		this.studentStaff = studentStaff;
	}
	
	public void setSalary(double salary) {
		studentStaff.setSalary(salary);
	}
	
	public double getSalary() {
		return studentStaff.getSalary();
	}
}
