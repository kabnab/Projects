
import java.util.ArrayList;
import java.util.List;

public class Student extends Person {
	
	private double gpa;
	protected List<Course> courses = new ArrayList<>();

	public Student(String name, String phone, int age, double gpa, List<Course> courses) {
		super(name, phone, age);
		this.gpa = gpa;
		this.courses = courses;
	}
	
	public Student(String name, String phone, int age, double gpa) {
		super(name, phone, age);
		this.gpa = gpa;
	}

	public double getGpa() {
		return gpa;
	}

	public void setGpa(double gpa) {
		this.gpa = gpa;
	}

	public List<Course> getCourses() {
		return courses;
	}

	public void setCourses(List<Course> courses) {
		this.courses = courses;
	}
	
	public void addCourse(Course c) {
		courses.add(c);
	}
	
	public int getTotalUnits() {
		int totalUnits = 0;
		for(Course c : courses) {
			totalUnits += c.getUnits();
		}
		return totalUnits;
	}

}
