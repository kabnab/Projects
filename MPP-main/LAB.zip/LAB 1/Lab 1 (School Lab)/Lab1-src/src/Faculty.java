package schoolLab2;

import java.util.ArrayList;
import java.util.List;

public class Faculty extends Person {

	private List<Course> courses = new ArrayList<>();
	private double salary;
	
	public Faculty(String name, String phone, int age, double salary) {
		super(name, phone, age);
		this.salary = salary;
	}

	public List<Course> getCourses() {
		return courses;
	}

	public void setCourses(List<Course> courses) {
		this.courses = courses;
	}
	
	public void addCourse(Course c) {
		courses.add(c);
	}
	
	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	
	public int getTotalUnits() {
		int totalUnits = 0;
		for(Course c : courses) {
			totalUnits += c.getUnits();
		}
		return totalUnits;
	}

}
