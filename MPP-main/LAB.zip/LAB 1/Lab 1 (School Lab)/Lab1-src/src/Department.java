package schoolLab2;

import java.util.ArrayList;
import java.util.List;

public class Department {
	
	private String depName;
	private List<Person> persons = new ArrayList<>();
	
	public Department(String depName, List<Person> persons) {
		this.depName = depName;
		this.persons = persons;
	}
	
	public Department(String depName) {
		this.depName = depName;
	}
	
	public String getDepName() {
		return depName;
	}

	public void setDepName(String depName) {
		this.depName = depName;
	}

	public List<Person> getPersons() {
		return persons;
	}

	public void setPersons(List<Person> persons) {
		this.persons = persons;
	}
	
	public void addPerson(Person p) {
		persons.add(p);
	}

	public double getTotalSalary1() {
		double totalSalary = 0;
		for(Person p : persons) {
			if (p instanceof Faculty) totalSalary += ((Faculty) p).getSalary();
			if (p instanceof Staff) totalSalary += ((Staff) p).getSalary();
			if (p instanceof StaffStudent) totalSalary += ((StaffStudent) p).getSalary();
		}
		return totalSalary;
	}
	
	public double getTotalSalary2() {
		double totalSalary = 0;
		for(Person p : persons) {
			totalSalary += p.getSalary();
		}
		return totalSalary;
	}
	
	public void showAllMembers() {
		System.out.println("List of " + getDepName() + " Deparment Members");
		String f = "%nMember Name: %-15sPhone Number: %-12sAge: %-5dGroup: %s";
		for(Person p : persons) {
			System.out.printf(f, p.getName(), p.getPhone(), p.getAge(), p.getClass().getSimpleName());
		}
		System.out.println("\n");
	}
	
	public void unitsPerFaculty1() {
		System.out.println("Number of Units per Faculty");
		for(Person p : persons) {
			if(p instanceof Faculty) {
				String f = "%nFaculty Name: %-15sCourse Units: %d";
				System.out.printf(f, p.getName(), ((Faculty) p).getTotalUnits());
			}
		}
		System.out.println("\n");
	}
	
	public void unitsPerFaculty2() {
		System.out.println("Number of Units per Faculty");
		for(Person p : persons) {
			if(p.getClass().getSimpleName().equals("Faculty")) {
				String f = "%nFaculty Name: %-15sCourse Units: %d";
				System.out.printf(f, p.getName(), p.getTotalUnits());
			}
		}
		System.out.println("\n");
	}
	
	public void returnStudentsOf(String facultyName) {
		List<String> studentList = new ArrayList<>();
		boolean checkName = false;
		for(Person p : persons) {
			List<Course> courseList = new ArrayList<>();
			if(p instanceof Faculty && facultyName.equals(p.getName())) {
				courseList = ((Faculty) p).getCourses();
				checkName = true;
			}
			for(Course c : courseList) {
				for(Person q : persons) {
					if(q instanceof Student && ((Student) q).getCourses().contains(c)) {
						studentList.add(q.getName());
					}
				}
			}
		}
		if(checkName == false) System.out.println("Invalid Faculty Name");
		else if(studentList.size() == 0) System.out.println("Faculty has no Students");
		else {
			System.out.println("Students of " + facultyName + " are:");
			studentList.stream().distinct().forEach(System.out::println);
		}
		System.out.println();
	}

}
