package schoolLab2;

public class Person {
	
	protected String name;
	protected String phone;
	protected int age;
	
	public Person(String name, String phone, int age) {
		this.name = name;
		this.phone = phone;
		this.age = age;
	}
	
	public Person(String name, String phone, int age, double salary) {
		this.name = name;
		this.phone = phone;
		this.age = age;
		salary = getSalary();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public void addCourse(Course c) {
		
	}
	
	public int getTotalUnits() {
		return 0;
	}
	
	public double getSalary() {
		return 0;
	}
	
}
