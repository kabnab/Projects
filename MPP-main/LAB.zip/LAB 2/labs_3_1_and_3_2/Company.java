package labs_3_1_and_3_2;

import java.util.ArrayList;
import java.util.List;

public class Company {
	
	private String name;
	private List<Department> departments;
	
	Company(String name){
		this.name = name;
		this.departments = new ArrayList<Department>();
	}
	
	Company(){
		
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Department> getDepartments() {
		return departments;
	}

	public void setDepartments(List<Department> departments) {
		this.departments = departments;
	}
	
	public void addDepartment(Department d) {
		departments.add(d);
	}
	
	public void print() {
		System.out.println(name);
		for(Department d : departments) {
			d.print();
		}
		System.out.print("*******************************");
	}
	
	public double getSalary() {
		double totalSalary = 0;
		for(Department d : departments) {
			totalSalary += d.getSalary();
		}
		return totalSalary;
	}
	
}
