package labs_3_1_and_3_2;

public class Position {
	
	private String title;
	private String description;
	private Employee employee;
	
	public Position(String title, String decription, Employee employee) {
		this.title = title;
		this.description = decription;
		this.employee = employee;
		employee = new Employee();
	}
	
	public Position (){
		
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String decription) {
		this.description = decription;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	
	public void print() {
		System.out.println(" Position: " + title + " (" + description +")");
		if(employee != null) {
			employee.print();
			System.out.println();
		} else System.out.println("  Position is Vacant\n");
	}
	
	public double getSalary() {
		if(employee != null) {
		 return employee.getSalary();
		}
		return 0;
	}
}
