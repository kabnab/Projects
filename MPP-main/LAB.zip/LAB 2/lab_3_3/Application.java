package lab_3_3;

import java.time.LocalDate;

public class Application {

	public static void main(String[] args) {
		
		//creating company
		Company theCompany = new Company("KIA MOTORS");
		
		//adding departments to company
		Department salesDep = new Department("Sales", "Dallas");
		Department marketingDep = new Department("Marketing", "Iowa");
		Department management = new Department  ("Executive", "Texas");
		
		//creating employees in management department
		Employee lyle = new Employee(100, "Lyle", 'M', "Johnson", LocalDate.of(1983, 12, 5), "56-8909-345", 300000);
		
		//creating employees in sales department
		Employee ron = new Employee(101, "Ron", 'K', "Thomas", LocalDate.of(1985, 12, 5), "668-90-9345", 95000);
		Employee stan = new Employee(110, "Stan", 'W', "Allen", LocalDate.of(1995, 1, 15), "568-90-9345", 85000);
		Employee peter = new Employee(120, "Peter", 'B', "Daniel", LocalDate.of(1988, 7, 25), "768-90-9345", 85000);
		Employee tom = new Employee(111, "Tom", 'N', "Michael", LocalDate.of(1985, 10, 9), "468-90-9345", 45000);
		Employee sue = new Employee(112, "Sue", 'W', "Jong", LocalDate.of(1995, 1, 15), "168-90-9345", 45000);
		Employee mark = new Employee(113, "Mark", 'B', "Daniel", LocalDate.of(1988, 7, 25), "268-90-9345", 45000);
		Employee bill = new Employee(121, "Bill", 'N', "Smith", LocalDate.of(1985, 10, 9), "368-90-9345", 35000);
		Employee dan = new Employee(122, "Dan", 'N', "Trump", LocalDate.of(1985, 10, 9), "968-90-9345", 35000);
		
		//creating employees in marketing department
		Employee ann = new Employee(102, "Ann", 'N', "Cruz", LocalDate.of(1985, 10, 9), "756-09-3745", 95000);
		Employee gary = new Employee(130, "Gary", 'T', "Elliot", LocalDate.of(1985, 10, 9), "956-09-3745", 80000);
		Employee jan = new Employee(140, "Jan", 'W', "Mark", LocalDate.of(1975, 1, 9), "556-09-3745", 25000);
		
		//creating positions in sales
		Position ceo = new Position("CEO", "Cheif Executive Officer", lyle);
		
		//creating positions in sales
		Position salesHead = new Position("Department Head", "Sales Department Head", ron);
		Position teamLead1 = new Position("Supervisor", "Supervisor of Sales Persons", stan);
		Position teamLead2 = new Position("Coordinator", "Coordinator of Sales Persons", peter);
		Position salesPerson1 = new Position("Sales Officer I", "Intern Sales Person", tom);
		Position salesPerson2 = new Position("Sales Officer II", "Junior Sales Person", sue);
		Position salesPerson3 = new Position("Sales Officer III", "Mid Level Sales Person", mark);
		Position salesPerson4 = new Position("Sales Officer IV", "Senior Sales Person", bill);
		Position salesPerson5 = new Position("Sales Officer V", "Expert Sales Person", dan);
		Position janitor = new Position("General Service I", "Office Cleaner", jan);
		
		//adding positions hierarchy in sales
		salesHead.addInferior(teamLead1);
		salesHead.addInferior(teamLead2);
		teamLead1.addInferior(salesPerson1);
		teamLead1.addInferior(salesPerson2);
		teamLead1.addInferior(salesPerson3);
		teamLead2.addInferior(salesPerson4);
		teamLead2.addInferior(salesPerson5);
		salesPerson4.addInferior(janitor);
		
		teamLead1.setSuperior(salesHead);
		teamLead2.setSuperior(salesHead);
		salesPerson1.setSuperior(teamLead1);
		salesPerson2.setSuperior(teamLead1);
		salesPerson3.setSuperior(teamLead1);
		salesPerson4.setSuperior(teamLead2);
		salesPerson5.setSuperior(teamLead2);
		janitor.setSuperior(salesPerson4);
		
		//positions in marketing
		Position marketingHead = new Position("Department Head", "Marketing Department Head", ann);
		Position publicRelations = new Position("PR Officer", "Public Relations Liason", gary);
		
		//adding positions hierarchy in management
		ceo.addInferior(salesHead);
		ceo.addInferior(marketingHead);
		salesHead.setSuperior(ceo);
		marketingHead.setSuperior(ceo);
		
		//adding positions hierarchy in marketing
		marketingHead.addInferior(publicRelations);
		publicRelations.setSuperior(marketingHead);
		
		theCompany.addDepartment(salesDep);
		theCompany.addDepartment(marketingDep);
		theCompany.addDepartment(management);
		
		//adding positions to departments
		management.addPosition(ceo);
		salesDep.addPosition(salesHead);
		salesDep.addPosition(teamLead1);
		salesDep.addPosition(teamLead2);
		salesDep.addPosition(salesPerson1);
		salesDep.addPosition(salesPerson2);
		salesDep.addPosition(salesPerson3);
		salesDep.addPosition(salesPerson4);
		salesDep.addPosition(salesPerson5);
		salesDep.addPosition(janitor);
		marketingDep.addPosition(marketingHead);
		marketingDep.addPosition(publicRelations);
		
//		theCompany.print();
//		System.out.printf("TOTAL Salary of %s is $ %,.2f", theCompany.getName(),theCompany.getSalary());
//		salesHead.printDownLine();
//		marketingDep.getDepartmentHead().print();
//		ceo.printDownLine();
//		management.printReportingHierarchy();
		theCompany.printReportingHierarchy();
	
	}

}
