package lab_3_3;

import java.util.ArrayList;
import java.util.List;

public class Position {
	
	private String title;
	private String description;
	private Employee employee;
	private Position superior;
	private List<Position> inferiors;
	
	public Position(String title, String decription, Employee employee) {
		this.title = title;
		this.description = decription;
		this.employee = employee;
		employee = new Employee();
		superior = new Position();
		inferiors = new ArrayList<>();
	}
	
	public Position (){
		
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String decription) {
		this.description = decription;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	
	public Position getSuperior() {
		return superior;
	}

	public void setSuperior(Position superior) {
		this.superior = superior;
	}

	public List<Position> getInferiors() {
		return inferiors;
	}

	public void setInferiors(List<Position> inferiors) {
		this.inferiors = inferiors;
	}
	
	public void print() {
		System.out.println(" Position: " + title + " (" + description +")");
		if(employee != null) {
			employee.print();
			System.out.println();
		} else System.out.println("  Position is Vacant\n");
	}
	
	public double getSalary() {
		if(employee != null) {
		 return employee.getSalary();
		}
		return 0;
	}
	
	public void addInferior(Position p) {
		inferiors.add(p);
		inferiors.addAll(p.inferiors);
	}
	
	public boolean isManager() {
		if(superior == null) return true;
		return false;
	}
	
	public void printDownLine() {
		String indent = "";
		Position current = this;
		while(true) {
			if(current.isManager()) break;
			indent += "  ";
			current = current.getSuperior();
		}
		System.out.println(indent + this.getTitle() + "(" + this.getDescription() + ")");
		for(Position p : this.getInferiors()) {
			if(this.getInferiors().size() == 0) continue;
			p.printDownLine();
		}
	}
	
}
