package lab4;

public class Test {

	
	public static void main(String[] args) {
		ClosedCurve traingle = new Triangle(4,5,6);
		ClosedCurve square = new Square(3);
		ClosedCurve rectangle = new Rectangle(3,7);
		ClosedCurve circle = new Circle(3);
		System.out.println("The area of this Triangle is "+ traingle.computeArea());
		System.out.println("The area of this Square is "+ square.computeArea());
		System.out.println("The area of this Rectangle is "+ rectangle.computeArea());
		System.out.println("The area of this Circle is "+ circle.computeArea());
		
	}
}
