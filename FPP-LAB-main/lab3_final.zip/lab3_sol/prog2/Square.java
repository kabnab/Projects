package lab4;

public class Square extends ClosedCurve {
       int side;
public Square(int s) {
	this.side =s;
}
	@Override
	double computeArea() {
		// TODO Auto-generated method stub
		return side*side;
	}
}
