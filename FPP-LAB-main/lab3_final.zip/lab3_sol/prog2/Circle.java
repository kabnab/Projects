package lab4;

public class Circle extends ClosedCurve {
       int radius;
	  public Circle(int r) {
		  this.radius = r;
	  }
	@Override
	double computeArea() {
		// TODO Auto-generated method stub
		return Math.PI*radius*radius;
	}

}
