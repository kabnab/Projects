package lab4;

public class Triangle extends ClosedCurve {

	  int base;
	  int height;
	  int third = 0;
	
	public Triangle(int a , int b) {
		if(a<b) {
		this.base = a;
		this.height = b;
		}
		else {
			this.base=b;
		this.height =a;}
	}
	public Triangle(int a,int b,int c) {
		this.base = a;
		this.height = b;
		this.third = c;
	}
	@Override
	double computeArea() {
		double result ;
		if(third ==0) {
			result  = 0.5*base*height;
		}
		else {
			double u = (base+height+third)/2;
			result =Math.sqrt(u*(u-base)*(u-height)*(u-third));
		}
		// TODO Auto-generated method stub
		return result;
	}

}
