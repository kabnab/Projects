package lab4;

public abstract class ClosedCurve {
abstract double computeArea();
}
