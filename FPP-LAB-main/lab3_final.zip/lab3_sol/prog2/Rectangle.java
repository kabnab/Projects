package lab4;

public class Rectangle extends ClosedCurve {
  int length;
  int width;
  public Rectangle(int a , int b) {
	  this.length = a;
	  this.width = b;
  }
@Override
double computeArea() {
	
	return length * width;
	// TODO Auto-generated method stub
	
}
}
