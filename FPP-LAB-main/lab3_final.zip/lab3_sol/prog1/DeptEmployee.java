package prog1;

import java.time.LocalDate;

public class DeptEmployee {
	String name;
	int salary;
	LocalDate hairdate;
	DeptEmployee(String name,int salary,LocalDate hairdate){
		this.name=name;
		this.salary = salary;
		this.hairdate = hairdate;
		
	}
	 public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public LocalDate getHairdate() {
		return hairdate;
	}
	public void setHairdate(LocalDate hairdate) {
		this.hairdate = hairdate;
	}
	String getname() {
		return name;}
	
	int computesalary() {
		return salary;
	}

}
