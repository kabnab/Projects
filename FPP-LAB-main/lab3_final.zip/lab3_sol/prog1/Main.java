package prog1;
import java.time.LocalDate;
import java.util.Scanner;
public class Main {


public static void main (String[] args) {

LocalDate a = LocalDate.now();
Professor p1 =  new Professor("nahom", 16000,   a);
p1.setnumofp(10);
Professor p2 =  new Professor("fili", 100,   a);
p2.setnumofp(10);
Professor p3=  new Professor("amir", 400,   a);
Secretary t1 = new Secretary("tirhas",6000,LocalDate.of(2012,06,03),200);
Secretary t2 = new Secretary("letish",8000,LocalDate.of(2018,06,04),200);
DeptEmployee[] department = new DeptEmployee[5];
department[0] = p1;
department[1] = p2;
department[2] = t1;
department[3] = t2;
department[4] = p2;

Scanner sc  = new Scanner(System.in);
System.out.println("would like report?");
double sum  =0;
String b = sc.nextLine();
	if(b.charAt(0) == 'y') {
		for(DeptEmployee x: department) 
			sum+=x.computesalary();
		System.out.println(sum);
		
	}
	else
		System.out.println("ok Have a good day!!");
	
}
}

