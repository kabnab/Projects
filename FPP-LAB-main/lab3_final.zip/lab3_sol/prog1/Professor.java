package prog1;

import java.time.LocalDate;

public class Professor extends DeptEmployee {
    Professor(String name, int salary, LocalDate hairdate) {
		super(name, salary, hairdate);
		// TODO Auto-generated constructor stub
	}
	int Numofpublic;
   int getnumb() {
	   return Numofpublic;
   }
   void setnumofp(int a) {
	   Numofpublic =a;
   }
}
