package prog1;

import java.time.LocalDate;

public class Secretary extends DeptEmployee {
	double overth;
	Secretary(String name, int salary, LocalDate hairdate,double overth) {
		super(name, salary, hairdate);
		this.overth= overth;
		// TODO Auto-generated constructor stub
	}
	double getovth() {
		return overth;
	}
	  void setovrth(double b) {
		  overth =b;
	  }
	  
	  int computesalary() {
		 return (int)(12*overth) + super.salary;
		  
	  }
/*Secretary(String name, int salary, LocalDate hairdate ) {
		super(name, salary, hairdate); 
		
	}*/

;
}
