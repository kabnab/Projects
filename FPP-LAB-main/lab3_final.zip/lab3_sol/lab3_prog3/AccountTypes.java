package assignment4_3employeeinfo;

public enum AccountTypes {
	CHECKING, SAVINGS, RETIREMENT;
}
