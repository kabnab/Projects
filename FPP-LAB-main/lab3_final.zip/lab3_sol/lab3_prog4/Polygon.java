package lab3;

public interface Polygon {

	public int getNumberOfSides();

	public double computePerimeter();

}
