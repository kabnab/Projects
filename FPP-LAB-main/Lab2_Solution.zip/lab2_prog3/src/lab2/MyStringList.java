package lab2;

public class MyStringList {

	int size;
	int added=0;
	int rem = 0;
	String[] strArray ;
	public MyStringList() {
		strArray = new String[50];
		size=0;
	}
	public void add(String s) {
        if(size==strArray.length-1)
	   resize();
	strArray[size] = s;
	size++;
	added++;
	}
	
	public String get(int i) {
		return strArray[i];
	}
	public boolean find(String s) {
		boolean result = false;
		for(int i = 0 ;i<size;i++){
			if(strArray[i] == s) {
				result= true;}
		}
		return result;
	}
	
	
	public boolean remove(String s) {
		
		if (!find(s))
			return false;
		for (int i = 0; i < size; i++) {
			if (s.equals(strArray[i])) {
				for (int k = i+1; k < size; k++) {
					String temp = strArray[k];
					strArray[k-1] = temp;
				}
				i = size;
				size--;rem++;
			}
		}
		return true;
	}
	
	public String toString() {
		String result="[";
		for(int x = 0;x<size;x++) {
			result+=  strArray[x];
		if(x==size-1)
			continue;
		else
			result+=", ";
		}
		   
		result += "]";
		return result;
	}
	public int size() {
		return added-rem;
	}
private void resize() {
	String[] newString = new String[size*2];
	for(int i=0; i<size; i++) {
		newString[i]=strArray[i];
	}
	strArray= newString;
}
}
