package lab2;

import java.time.LocalDate;
import java.util.Date;
import java.util.GregorianCalendar;

public class Employee {

	private Account savingsAcct;
	private Account checkingAcct;
	private Account retirementAcct;
	private String name;
	private LocalDate hireDate;
	Employee emp;
	public Employee(String name, int yearOfHire, int monthOfHire, int dayOfHire){
		this.name = name;
/* update, using LocalDate
		GregorianCalendar cal = new GregorianCalendar(yearOfHire,monthOfHire-1,dayOfHire);
		hireDate = cal.getTime();
*/
	}
   public String getName() {
	   return this.name;
   }
	
	public void createNewChecking(double startAmount) {
		// implement
		checkingAcct = new Account(emp, AccountType.CHECKING_ACCOUNT,startAmount);
	}

	public void createNewSavings(double startAmount) {
		// implement
		savingsAcct = new Account(emp, AccountType.SAVINGS_ACCOUNT,startAmount);
	}

	public void createNewRetirement(double startAmount) {
		// implement
		retirementAcct = new Account(emp, AccountType.RETIREMENT_ACCOUNT,startAmount);
	}

	public String getFormattedAcctInfo() {
		// implement
		  String a = "";
		  if(checkingAcct!= null)
			a+=  checkingAcct.toString();
		  if(savingsAcct!=null)
			  a+=savingsAcct.toString();
		  if(retirementAcct != null)
			  a+=retirementAcct.toString();
		  
		return a;
	}
	public void deposit(String acctType, double amt){
		// implement
		switch (acctType) {
		case "checking":
			checkingAcct.makeDeposit(amt);break;
		case "savings":
			savingsAcct.makeDeposit(amt);break;
		case "retirement":
			retirementAcct.makeDeposit(amt);break;
		}
	}
	public boolean withdraw(String acctType, double amt){
		// implement
		boolean result = true;
		switch (acctType) {
		case "checking":
			  if(checkingAcct.getbal()<amt)
				  {result = false;break;}
			  else {
				  checkingAcct.makeWithdrawal(amt);
			  }
			
		case "savings":
			 if(savingsAcct.getbal()<amt)
			  {result = false;break;}
		  else {
			  savingsAcct.makeWithdrawal(amt);
		  }
		case "retirement":
			 if(retirementAcct.getbal()<amt)
			  {result = false;break;}
		  else {
			  retirementAcct.makeWithdrawal(amt);
		  }
		}
		return result;
	}

}
