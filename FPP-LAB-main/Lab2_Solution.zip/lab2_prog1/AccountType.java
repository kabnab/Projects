package lab2;

public enum AccountType {
	CHECKING_ACCOUNT, SAVINGS_ACCOUNT, RETIREMENT_ACCOUNT
}
