package lab4;

public class test {
 
	
	 public static void main(String[] args) {
		 
		 MySingleton a  = MySingleton.getinstance();
		 MySingleton b  = MySingleton.getinstance();
		 System.out.println(a);
		 System.out.println(b);
		 
	 }
}
