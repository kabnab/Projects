package lab4;

public class MySingleton {

     private static MySingleton single =null;
     String s;
     private MySingleton() {
    	 s= "Single instance";
     }
     public static MySingleton getinstance() {
    	 if(single==null)
    		 single = new MySingleton();
    	 
    	 return single;
    	 
    	 
    	 
     }
}
