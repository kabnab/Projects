package lab4;

import lab4.Top.Middle.Bottom;
import lab4.Top.Middle;

public class Top {

	int t = 1;
	private Object Top;
	Middle mid  = new Middle();
	Bottom midbot  = mid.new Bottom(); 
	//returns the value in the instance vble of Bottom
	int readBottom() {
		//implement
	
		return midbot.b;
	}
	 class Middle {
		int m = 2;
		//returns sum of instance vble in Top and 
		//instance vble in Bottom
		int addTopAndBottom() {
			//implement
			
		return midbot.b+t;
			
		}
		class Bottom {
			int b = 3;
			//returns the product of the instance vbles
			//in all three classes
			int multiplyAllThree() {
				//implement
				return t * b*m;
			}
		}
	}
	public static void main(String[] args){
		Top top = new Top();

		System.out.println(top.readBottom());
		System.out.println(top.mid.addTopAndBottom());
		System.out.println(top.midbot.multiplyAllThree());

	}

}