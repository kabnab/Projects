
public class OverdrawnAccountException extends Exception {
   public OverdrawnAccountException(String meg) {
	   super(meg);
   }
}
