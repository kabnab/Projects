

public enum AccountType {
	CHECKING, 
	SAVINGS, 
	RETIREMENT;
}
