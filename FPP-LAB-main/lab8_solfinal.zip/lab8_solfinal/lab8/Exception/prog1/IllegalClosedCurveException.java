
public class IllegalClosedCurveException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5217162990678251629L;

	public IllegalClosedCurveException(String meg) {
		super(meg);
	}
	public IllegalClosedCurveException() {
		// TODO Auto-generated constructor stub
	}
	class  IllegalTriangleException extends Exception{
		   public IllegalTriangleException(String meg) {
			   super(meg);
		   }
	}

}
