

public class Square extends ClosedCurve {
	double side;
	public Square(Double side)throws IllegalClosedCurveException{
		
		if(side<0) {
			throw new IllegalClosedCurveException(
					"An IllegalClosedCurveException was thrown in a Square instance. ");
		}
		else
			this.side =side;
	}
	public Square(double side) {
		this.side = side;
	}
	double computeArea() {
		return(side*side);
	}

}
