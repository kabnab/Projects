

public class Circle extends ClosedCurve {
	double radius;
	public Circle(Double radius) throws IllegalClosedCurveException{
		
		if(radius<0) {
			throw new IllegalClosedCurveException(
					"An IllegalClosedCurveException was thrown in a Circle instance. ");
		}
		else
			this.radius=radius;
		
	}
	public Circle(double radius) {
		this.radius = radius;
	}
	double computeArea() {
		return (Math.PI * radius * radius);
	}
}
