public class MinSort{
      String sorting(String s){
        if( s.length() == 0)
            return "";//samrawit

              char c = s.charAt(minpos(s));
              s = s.substring(0,minpos(s))+s.substring(minpos(s)+1);
              return c+sorting(s);

    }

     int minpos(String s){
        int min=0;
        for(int i=1;i<s.length();i++){
            if(s.charAt(i)<s.charAt(min))
                min=i;
        }
        return min;
    }

  public static void main(String[] args){
         MinSort c = new MinSort();

       String s  = "wjwfgkwfkjiosdjfsamrawitjudybininahommihre";
       System.out.println(c.sorting(s));
  }

}