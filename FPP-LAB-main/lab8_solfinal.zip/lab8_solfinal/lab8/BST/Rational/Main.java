package lab8;

public class Main {
public static void main(String[] args) {
	Rational r1 = new Rational(2,3);
	Rational r2 = new Rational(2,4);
	Rational r3 =r1.add(r2);
	int a = r1.compareTo(r2);
	System.out.println(r3);
	System.out.println(a);
}
}