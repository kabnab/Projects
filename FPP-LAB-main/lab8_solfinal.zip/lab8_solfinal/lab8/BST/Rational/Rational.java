package lab8;

import java.util.Objects;

public class Rational {
int p;int q;
	
	public Rational(int a ,int b) {
		this.p = a;
		if(!(b>0)) {
			System.out.println("Error denominator must be postive");
		}
		else 
			this.q=b;
	}
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return Objects.hash(p,q);
	}
	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		if(!(obj instanceof Rational))
			return false;
		Rational s = (Rational)obj;
		return (p*s.q) == (q*s.p);
	}
	@Override
	public String toString() {
		return  p + "/"+ q ;
	}
	//adds the rational rat to this Rational
	public Rational add(Rational rat) {
		Rational R = new Rational((p*rat.getQ()+q*rat.getP()), q*rat.getQ());
		return R;
	}
	public int getP() {
		return p;
	}
	public void setP(int p) {
		this.p = p;
	}
	public int getQ() {
		return q;
	}
	public void setQ(int q) {
		this.q = q;
	}
	//multiplies rat by this Rational
	public Rational multiply(Rational rat) {
		//returns 1 if this rational is greater than rat
		Rational R = new Rational(p*rat.getP(),q*rat.getQ());
		return R;
	} 
	//returns �1 if this rational is less than rat
	//returns 0 if this rational equals (see equals 
	// method discussion below) rat
	
	public int compareTo(Rational rat) {
		int r=0;
		if((p*rat.q)<(q*rat.p))
			r=-1;
		else if((p*rat.q)==(q*rat.p))
			r=0;
		else
			r=1;
		return r;
	}
}
