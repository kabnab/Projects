package sortroutines;
import runtime.Sorter;

public class BSTSort extends Sorter {
     MyBST bst = new MyBST();
	@Override
	public int[] sort(int[] arr) {
		// TODO Auto-generated method stub
		bst.insertAll(arr);
		return bst.readIntoArray();
		
	}

}
