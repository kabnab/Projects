import java.util.ArrayList;
import java.util.List;

public class Schur {                        
  static  boolean checkForSum(List<Integer> list , int z) {
    	for(int t:list) {
    		if(list.contains(z-t))
    			return true;
    	}
    	return false;
    }
    
    public static void main(String[] args) {
    	List<Integer> list = new ArrayList<>();
    	int[] l  = {2,4,4,5,56,6,6,2,5,7,3,6,4};
    	for(int a :l)
    		list.add(a);
    	System.out.println(checkForSum(list,0));
    }
}
