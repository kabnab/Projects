To read this Employee file for the symbol-balancing lab,
place it at the top level of your project (if you
place it in the same package as your Java class,
the JVM will not find your file unless you give
the full pathname too).