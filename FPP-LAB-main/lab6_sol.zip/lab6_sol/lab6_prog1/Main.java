
public class Main {

	   public static void main(String[] args) {
		   MyStack s  =  new MyStack();
		   s.push("amir");
		  
		   s.push("amir1");
		   s.push("amir2");
		   s.push("amir3");
		   
		   s.pop();
		   System.out.println(s);
	   }
}
