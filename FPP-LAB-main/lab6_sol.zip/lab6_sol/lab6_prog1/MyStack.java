

public class MyStack {
	private MyStringLinkedList list;
	public MyStack() {
		list = new MyStringLinkedList();
	}
	
	public String pop() {
		//implement
		
	list.remove(0);
	return list.toString();
	}
	public String peek() {
		//implement
		return list.get(0);
	}
	
	public void push(String s) {
		//implement
		list.add(s);
	}
	public String toString() {return
			list.toString();
		
	}
}
