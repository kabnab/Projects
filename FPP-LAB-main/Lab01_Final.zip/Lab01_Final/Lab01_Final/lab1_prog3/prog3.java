package lab1;

public class prog3 {

	
	public static void main(String[] args) {
	float a =  1.27f,b=   3.881f , c =   9.6f;
	double sum2 =  (a+b+c);
	int sum = (int) (a+b+c);
	System.out.println(sum);
	System.out.println(Math.round(a+b+c));
	}

}
