
import java.util.*;
import java.io.*;
public class prog5 {

	
	public static void main(String[] args) {
		System.out.println("Please Enter Anything :)");
		Scanner sc =new Scanner(System.in);
		String a = sc.nextLine();
		String[] r = a.split("");
		String result="";
		for(int i = a.length()-1; i>=0 ;i--) {
			result+= r[i];
		}
		
		System.out.println(result);
	}
}
