package lab1;

//P2-1
 class Address{
	
	String streetname;
	String country;
	public Address(String sn, String Co) {
		this.streetname = sn;
		this.country = Co;
	}
	
}

public class Customer {
	
	
	String firstName,lastName,socSecurityNum;
	Address badr;
	Address sadr;
	public Customer(String fn, String ln , String ssn, Address sadd, Address badd) {
		this.firstName =fn;
		this.lastName =ln;
		this.socSecurityNum = ssn;
		this.sadr = sadd;
		this.badr = badd;
	}
	Address getbad() {
		return badr;
	}
	Address getsad() {
		return sadr;
	}
	void setbad(Address a) {
		badr=a;
	}
	void setsad(Address v) {
		sadr =v;
	}
	String getfname() {
		return firstName ;
	}
	
	String getlname() {
		return lastName ;
	}
	void setfname(String a) {
		this.firstName =a;
	}
	void setlname(String b) {
		this.lastName = b;
	}
	void setssn(String e) {
		this.socSecurityNum = e;
	}
	public String toString() {
		return "[ " +firstName + " " +lastName+" "+ "SSN: "+ socSecurityNum+"]";
	}
	public static void main(String[] args) {
		Address a1 =  new Address("opwa", "USA");
		Address a2 =  new Address("chicago","UAE");
		Customer c1 = new Customer("filmon","yemane","28384",a1,a1);
		Customer c2 = new Customer("nahom","tietie","823458872",a2,a2);
		Customer[] p = {c1,c2};
		for(Customer cust: p) {
			if(cust.badr.streetname == "chicago")
				System.out.println(cust.toString());
			
		}
		
	}
}
