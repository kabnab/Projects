package lab1;
import junit.framework.TestCase;



public class prog8test extends TestCase{
	 
	
    public void testmin() {
    	  int[] testdata = {2,3,4,3,4,3};
	assertEquals(2, prog8.min(testdata));
      }
        
   
    
     
}

