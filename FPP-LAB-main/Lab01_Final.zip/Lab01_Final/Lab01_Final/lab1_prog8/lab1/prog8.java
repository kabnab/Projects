package lab1;

public class prog8 {

	static int min(int[] arrayOfInts) {
		int m = 999999;
		for(int i : arrayOfInts) {
			if(i<m)
				m =i;
		}
		return m;
	}
	
	public static void main(String[] args) {
		int[] a = {2,3,4,2,4,2,4,23,4,34,34};
		System.out.println(min(a));
	}
}
