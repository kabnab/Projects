package lab1;

public class prog4 {
public static void main (String[] args) {
	String mystring = Data.records;
	String[] separated = mystring.split(":");
	for(int i =0;i<separated.length;i++) {
		
		String[] sp = separated[i].split(",");
		System.out.println(sp[0]);
		
	}
}
	
	
}
