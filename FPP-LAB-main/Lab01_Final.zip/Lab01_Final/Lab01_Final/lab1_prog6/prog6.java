package lab1;
import java.util.*;
public class prog6 {

	static String[] removeDups(String[] a) {
		List<String> result = new ArrayList<>();
		for(int i = 0;i<a.length;i++) {
			if(result.contains(a[i]))
				continue;
			else
				result.add(a[i]);
			
		}
		
		return result.toArray(new String[0]);
	}
	
	public static void main(String[] args) {
		String[] arr = {"wew","re","re"};
		String[] test = removeDups(arr);
		for(String x:test)
			System.out.println(x);
	}
}
